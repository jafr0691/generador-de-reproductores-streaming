<?php
    $UsuarioDB='volucion_player2';
	$PasswdDB='kC6I=V4pC)QK';
	$HostDB='66.225.201.21';
	$NombreDB='volucion_reproductores2019';
	$ConsultaDB = new mysqli($HostDB,$UsuarioDB,$PasswdDB,$NombreDB);
	$ConsultaDB->set_charset("utf8");
?>