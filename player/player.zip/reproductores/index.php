<?php
	/*Base de Datos*/
	include ('./db.php');

	$IDR = base64_decode(addslashes(htmlentities(strip_tags($_GET['idr']))));
	$ArrayGET=array_keys($_GET);
	$Seccion=$ArrayGET[0];



	//Verifico que la radio sea por ID, caso contrario, uso la conf. vía GET.
	if($Seccion!='contacto'){

		if(!$IDR || empty($IDR)){
			//Configuración vía get
			$Tema=addslashes(htmlentities(strip_tags($_GET['tema'])));
			$Color=trim(addslashes(htmlentities(strip_tags($_GET['color']))));
			if(strlen($Color)==6)
				$Color = '#'.$Color;
				
			$IP=addslashes(htmlentities(strip_tags($_GET['ip'])));
			$Puerto=addslashes(htmlentities(strip_tags($_GET['puerto'])));
			$Montaje=addslashes(htmlentities(strip_tags($_GET['montaje'])));
			$play=addslashes(htmlentities(strip_tags($_GET['autoplay'])));
			$vrt=addslashes(htmlentities(strip_tags($_GET['vrt'])));
			$Blur=addslashes(htmlentities(strip_tags($_GET['blur'])));
			$Mampara=addslashes(htmlentities(strip_tags($_GET['Mampara'])));
			$abtn=addslashes(htmlentities(strip_tags($_GET['abtn'])));

			$TituloEmisora=addslashes(htmlentities(strip_tags($_GET['titulo'])));
			$Logo = addslashes(htmlentities(strip_tags($_GET['logo'])));
			$btn=addslashes(htmlentities(strip_tags($_GET['btn'])));
			$Facebook=addslashes(htmlentities(strip_tags($_GET['facebook'])));
			$Twitter=addslashes(htmlentities(strip_tags($_GET['twitter'])));

			$Playstore=addslashes(htmlentities(strip_tags($_GET['playstore'])));
			$enlace=addslashes(htmlentities(strip_tags($_GET['enlace'])));
			$Iphone=addslashes(htmlentities(strip_tags($_GET['iphone'])));
			$Winamp=addslashes(htmlentities(strip_tags($_GET['winamp'])));
			$Messenger=addslashes(htmlentities(strip_tags($_GET['messenger'])));
			$Whatsapp=addslashes(htmlentities(strip_tags($_GET['Whatsapp'])));
			$Instagram=addslashes(htmlentities(strip_tags($_GET['instagram'])));
			
			$Late=addslashes(htmlentities(strip_tags($_GET['latidos'])));
			$Artista=addslashes(htmlentities(strip_tags($_GET['artista'])));
			$Cancion=addslashes(htmlentities(strip_tags($_GET['cancion'])));
			$Logo2 = addslashes(htmlentities(strip_tags($_GET['imgfacebook'])));
		}else{

			if($Resultado=$ConsultaDB->query("SELECT * FROM reproductores WHERE ID='$IDR'")){
				$Datos=$Resultado->fetch_array();
				$Tema=$Datos['Tema'];
				$Color=$Datos['Color'];
				if(strlen($Color)==6)
					$Color='#'.$Datos['Color'];

				$IP=$Datos['Servidor'];
				$Puerto=$Datos['Puerto'];
				$Montaje=$Datos['Montaje'];
				$play=$Datos['Autoplay'];
				$vrt=$Datos['vertical'];
				$Blur=$Datos['Blur'];
				$Mampara=$Datos['Mampara'];
				$abtn=$Datos['abtn'];
				
				$Artista=$Datos['Artista'];
				$Late=$Datos['Latido'];
				$Cancion=$Datos['Cancion'];

				$TituloEmisora=$Datos['TituloEmisora'];
				$Logo=$Datos['Logo'];
				$Logo2=$Datos['Logo2'];
				$btn=$Datos['btn'];
				$Facebook=$Datos['Facebook'];
				$Twitter=$Datos['Twitter'];

				$Playstore=$Datos['Playstore'];
				$enlace=$Datos['enlace'];
				$Iphone=$Datos['Iphone'];
				$Winamp=$Datos['Winamp'];
				$Messenger=$Datos['Messenger'];
				$Whatsapp=$Datos['Whatsapp'];
				$Instagram=$Datos['Instagram'];
			}
		}
	}
	
	
?>
<!DOCTYPE html>
<html lang="es" >
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        
<link href="https://clientes.evolucionstreaming.com/templates/templates-six-master/img/FAVICON_64X64-1-1.ico" rel="icon" title="Evoluci贸n Streaming - Servicios Inform谩ticos" type="image/x-icon" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta name="description" content="Escucha las mejores radios en un solo lugar, ¡ingresa ahora y disfruta!">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta property="og:type" content="movie"/>
<meta property="og:description" content="📻 🎧 🎙 Escuchanos en vivo | EVOLUCION STREAMING 🎙 🎧 📻"/>
<meta property="og:image" content="<?php echo $Logo2;?>"/>
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="250" />
<meta property="fb:app_id" content="396838644238555" />
<meta property="og:title" content=":: <?php echo $TituloEmisora; ?> - STREAMING SSL ::"/>
<meta property="og:url" content="https://www.html5player.evolucionstreaming.com/reproductores/?idr=<?php echo base64_encode($IDR); ?>"/>

        <link href="css/tema-<?php echo $Tema;?>.css?<?php echo base64_encode($IDR); ?>=<?php echo base64_encode($IDR); ?>" type="text/css" rel="stylesheet" />
   
      
  </head>
 <style>
    .desaparece{display:none}
     @keyframes latidos {
    from { transform: none; }
    50% { transform: scale(1.2); }
    to { transform: none; }
}

</style> 
  <body>
      
  	<?php
  		switch ($Seccion) {
			case 'contacto':
				include('inc/contacto.php');
				break;
			default:
				include('inc/inicio.php');
				break;
		}
  	?>
  </body>
</html>