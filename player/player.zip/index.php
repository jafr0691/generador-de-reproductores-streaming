<?php 
	session_start();
	$UsuarioDB='volucion_player2';
	$PasswdDB='kC6I=V4pC)QK';
	$HostDB='66.225.201.21';
	$NombreDB='volucion_reproductores2019';
	$ConsultaDB = new mysqli($HostDB,$UsuarioDB,$PasswdDB,$NombreDB);
	$ConsultaDB->set_charset("utf8");

$Tema=trim(addslashes(htmlentities(strip_tags($_POST['theme']))));
$Color=trim(addslashes(htmlentities(strip_tags($_POST['color']))));

	$IP=addslashes(htmlentities(strip_tags($_POST['ipemisora'])));
	$Puerto=addslashes(htmlentities(strip_tags($_POST['puerto'])));
	$Montaje=addslashes(htmlentities(strip_tags($_POST['montaje'])));
	$vrt=addslashes(htmlentities(strip_tags($_POST['vrt'])));
	$Mampara=addslashes(htmlentities(strip_tags($_POST['Mampara'])));
	$play=addslashes(htmlentities(strip_tags($_POST['autoplay'])));
	$Blur=addslashes(htmlentities(strip_tags($_POST['blur'])));
	$abtn=addslashes(htmlentities(strip_tags($_POST['abtn'])));
    $enlace=addslashes(htmlentities(strip_tags($_POST['enlace'])));
	$TituloEmisora=addslashes(htmlentities(strip_tags($_POST['emisora'])));
	$Logo = addslashes(htmlentities(strip_tags($_POST['logo'])));
	$btn=addslashes(htmlentities(strip_tags($_POST['btn'])));
	$Facebook=addslashes(htmlentities(strip_tags($_POST['facebook'])));
	$Twitter=addslashes(htmlentities(strip_tags($_POST['twitter'])));

	$Playstore=addslashes(htmlentities(strip_tags($_POST['playstore'])));
	$Winamp=addslashes(htmlentities(strip_tags($_POST['winamp'])));
	$Messenger=addslashes(htmlentities(strip_tags($_POST['messenger'])));
	$Whatsapp=addslashes(htmlentities(strip_tags($_POST['Whatsapp'])));
	$Instagram=addslashes(htmlentities(strip_tags($_POST['instagram'])));
	
	$Late=addslashes(htmlentities(strip_tags($_POST['latidos'])));
	$Artista=addslashes(htmlentities(strip_tags($_POST['artista'])));
	$Cancion=addslashes(htmlentities(strip_tags($_POST['cancion'])));
	$Logo2=addslashes(htmlentities(strip_tags($_POST['imgfacebook'])));

	//Verifico que los campos básicos no estén vacios.
	if(!empty($IP) && !empty($Puerto) && !empty($Montaje)){

		if(!isset($Tema) || empty($Tema)) $Tema='uno';
		//Inserto en la DB
		if($ConsultaDB->query("INSERT INTO reproductores (
				Tema,
				Color,
				Servidor,
				Puerto,
				Montaje,
				Autoplay,
				Blur,
				vertical,
				Mampara,
				TituloEmisora,
				Logo,
				Logo2,
				btn,
				Facebook,
				Twitter,
				Playstore,
				enlace,
				Winamp,
				Messenger,
				Whatsapp,
				Instagram,
				Latido,
				Cancion,
				Artista,
				abtn
			) VALUES (
				'$Tema',
				'$Color',
				'$IP',
				'$Puerto',
				'$Montaje',
				'$play',
				'$Blur',
				'$vrt',
				'$Mampara',
				'$TituloEmisora',
				'$Logo',
				'$Logo2',
				'$btn',
				'$Facebook',
				'$Twitter',
				'$Playstore',
				'$enlace',
				'$Winamp',
				'$Messenger',
				'$Whatsapp',
				'$Instagram',
				'$Late',
				'$Cancion',
				'$Artista',
				'$abtn'
			)")){
			$id_rep = $ConsultaDB->insert_id;
			$AlertaGenera='<div class="col-xs-12 alert alert-success text-center"><b>Reproductor generado correctamente. Copie y pegue el código de inserción que se encuentra debajo</b></div>';
			$InsertaSuccess=true;
		}else{
			$AlertaGenera='<div class="col-xs-12 alert alert-danger text-center"><b> Error al generar el reproductor. Favor de notificar al Administrador</b></div>';
		}
	}
	
?>

<!DOCTYPE html>
<html lang="es">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  	
  	<title>Evoluci&oacute;n Streaming - Servicios Inform&aacute;ticos</title>
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/v4-shims.css">
    <link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
    <link href="css/evolucionstream.css" type="text/css" rel="stylesheet" />
    <link href="css/fa/css/font-awesome.min.css" type="text/css" rel="stylesheet">
    <link href="https://clientes.evolucionstreaming.com/templates/templates-six-master/img/FAVICON_64X64-1-1.ico" rel="shortcut icon" title="Evolución Streaming - Servicios Informáticos" type="image/x-icon" />
    <link href="css/bootstrap-colorpicker.min.css" type="text/css" rel="stylesheet">
   <script>
	  function resizeIframe(obj) {
				obj.style.height = 0;
                obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
			}
	</script>
  
  </head>
  
  <style>
      .abtn-color,
.btn-color,
.btn-lay {
    width: 14px;
    height: 14px;
    display: inline-block;
    cursor: pointer
}
.abtn-color,
.btn-color {
    margin-right: 4px;
    border-radius: 50%
}

.btn-red {
    background: #F44336
}

.btn-pink {
    background: #E91E63
}

.btn-purple {
    background: #9C27B0
}

.btn-deeppurple {
    background: #673AB7
}

.btn-indigo {
    background: #3F51B5
}

.btn-blue {
    background: #2196F3
}

.btn-lightblue {
    background: #03A9F4
}

.btn-cyan {
    background: #00BCD4
}

.btn-teal {
    background: #009688
}

.btn-green {
    background: #4CAF50
}

.btn-lightgreen {
    background: #8BC34A
}

.btn-lime {
    background: #CDDC39
}

.btn-yellow {
    background: #FFEB3B
}

.btn-amber {
    background: #FFC107
}

.btn-orange {
    background: #FF9800
}

.btn-deeporange {
    background: #FF5722
}

.btn-brown {
    background: #795548
}

.btn-grey {
    background: #BDBDBD
}

.btn-bluegrey {
    background: #607D8B
}

.btn-darkblue {
    background: #163372
}

.btn-black {
    background: #262626
}

.btn-white {
    background: #F5F5F5
}

.abtn-red {
    background: #F44336
}

.abtn-pink {
    background: #E91E63
}

.abtn-purple {
    background: #9C27B0
}

.abtn-deeppurple {
    background: #673AB7
}

.abtn-indigo {
    background: #3F51B5
}

.abtn-blue {
    background: #2196F3
}

.abtn-lightblue {
    background: #03A9F4
}

.abtn-cyan {
    background: #00BCD4
}

.abtn-teal {
    background: #009688
}

.abtn-green {
    background: #4CAF50
}

.abtn-lightgreen {
    background: #8BC34A
}

.abtn-lime {
    background: #CDDC39
}

.abtn-yellow {
    background: #FFEB3B
}

.abtn-amber {
    background: #FFC107
}

.abtn-orange {
    background: #FF9800
}

.abtn-deeporange {
    background: #FF5722
}

.abtn-brown {
    background: #795548
}

.abtn-grey {
    background: #BDBDBD
}

.abtn-bluegrey {
    background: #607D8B
}

.abtn-darkblue {
    background: #163372
}

.abtn-black {
    background: #262626
}

.abtn-white {
    background: #F5F5F5
}
.slider.round {
    border-radius: 24px;
}
.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
}
.switch input {
    display: none;
}

user agent stylesheet
input[type="checkbox" i] {
    background-color: initial;
    cursor: default;
    -webkit-appearance: checkbox;
    box-sizing: border-box;
    margin: 3px 3px 3px 4px;
    padding: initial;
    border: initial;
}
input {
    -webkit-writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: -internal-light-dark-color(black, white);
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    -webkit-appearance: textfield;
    background-color: -internal-light-dark-color(white, black);
    -webkit-rtl-ordering: logical;
    cursor: text;
    margin: 0em;
    font: 400 13.3333px Arial;
    padding: 1px 0px;
    border-width: 2px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
}
user agent stylesheet
label {
    cursor: default;
}
input:checked+.slider {
    background-color: #008f39;
}
.slider.round {
    border-radius: 24px;
    width: 49px;
}
.slider {
    position: absolute;
    cursor: pointer;
    top: 25px;
    left:15px;
    right: 0;
    bottom: -5px;
    background-color: #ff0000;
    -webkit-transition: .4s;
    transition: .4s;
}
input:checked+.slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
}
.slider.round:before {
    border-radius: 50%;
}
.slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 4px;
    bottom: 4px;
    background-color: #fff;
    -webkit-transition: .4s;
    transition: .4s;
}

.tooltip {
  position: relative;
  display: inline-block;
  opacity: 1 !important;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 180px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px;
  position: absolute;
  z-index: 1;
  bottom: 150%;
  left: 20%;
  margin-left: -75px;
  opacity: 1 !important;
  transition: opacity 0.3s;
}

.tooltip .tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 20%;
  margin-left: 50px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1 !important;
}
      
  </style>
  
  <body ng-app="EVOLUCIONSTREAM">
  
  	<?php
  	$sesion_caverna_user=$_SESSION['usuarioLogueado'];

  	if($_POST && !empty($_POST['user']) && $_POST['user']=='evolucionstream' && !empty($_POST['pass']) && $_POST['pass']=='reproductorhtml5-2017'){
  		$_SESSION['usuarioLogueado']='evolucionstream';
  		echo '<script language = javascript>
	self.location = "?"
	</script>';
  		
  	}

  	if(isset($sesion_caverna_user) && $sesion_caverna_user=='evolucionstream'){
  	?>
  	
    <div class="container" ng-controller="Reproductor">
      
      <div class="col-xs-12 text-left" style="padding:15px 0px;">
<a href="/"><img src="img/logo.png" width="317px" height="auto"></a>
</div>
      
      <!--form-->
      <div class="col-md-8 MB10" style="padding-left: 0px;">
	
	
		<form action="" method="POST" id="form-principal">

		  <div class="col-xs-12"><h4>Generador Evolucion Streaming</h4></div>

		   <div class="form-group col-sm-4 MB10 ">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-gear"></i></span>
		      <select name="tiporadio" class="form-control" ng-model="versionSC" style="color:#999;" required="required">
		      	<option value="/stream" ng-init="versionSC='/stream'">ShoutCast v2</option>
		      </select>
		    </div>
		  </div>

		  <div class="inpu-group col-sm-8 MB10 ">
		    <div class="input-group col-xs-12" ng-show="versionSC">
		    	<span class="input-group-addon" id="basic-addon1"><i class="fa fa-server"></i></span>
		    	<select class="form-control" ng-model="ipemisora" name="ipemisora" id="ipemisora" required="required">
		    		<option value="streaming.evolucionstreaming.com" ng-init="ipemisora='streaming.evolucionstreaming.com'">streaming.evolucionstreaming.com</option>
		    		<option value="streaming.radiosenlinea.com.ar">streaming.radiosenlinea.com.ar</option>
		    		<option value="streaming01.shockmedia.com.ar">streaming01.shockmedia.com.ar</option>
		    		
		    	</select>
		    	<div class="input-group-field" style="width:20%;">
		      		<input type="text" class="form-control text-center SinPadding" ng-model="puerto" maxlength="5" name="puerto" placeholder="Puerto" style="border-left:0px;" ng-init="puerto='10965'">
	    		</div>
	    		<input type="hidden" name="asd">
	    		<div class="input-group-field" style="width:20%;">
		      		<input type="text" class="form-control text-center SinPadding"   maxlength="15" name="montaje" placeholder="Montaje" ng-model="versionSC">
	    		</div>
		    </div>
		  </div>

		  <div class="clearfix"></div>

		  <div class="form-group col-sm-6 MB10 ">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-microphone"></i></span>
		      <input type="text" maxlength="30" class="form-control" id="emisora" name="emisora" ng-model="emisora" placeholder="Nombre de la Emisora" onkeyup="mayus(this);countChars5(this);" required="required">
		      <span class="input-group-addon" id="charNum5">0 / 30</span>
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10 ">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-photo"></i></span>
		      <input type="text" maxlength="255" class="form-control" id="logo" name="logo" ng-model="logo" placeholder="Link del Logo Emisora" onkeyup="countChars7(this);">
		      <span class="input-group-addon" id="charNum7">0 / 255</span>
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-link"></i></span>
		      <input type="text" maxlength="50" class="form-control" id="enlace" name="enlace" ng-model="enlace" placeholder="URL Sitio Web" ng-init="enlace='https://www.evolucionstreaming.com'" onkeyup="countChars6(this);">
		      <span class="input-group-addon" id="charNum6">34 / 50</span>
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10 ">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-photo"></i></span>
		      <input type="text" maxlength="255" class="form-control" id="imgfacebook" name="imgfacebook" ng-model="imgfacebook" placeholder="Link Imagen Facebook" ng-init="imgfacebook='./reproductores/img/fb%20(1).png'" onkeyup="countChars4(this);">
		      <span class="input-group-addon" id="charNum4">32 / 255</span>
		    </div>
		  </div>

		  
		  <!--redes sociales-->
		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-facebook"></i></span>
		      <input type="text" class="form-control" name="facebook" ng-model="facebook" placeholder="https://www.facebook.com/usuario">
		    </div>
		  </div>
		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-twitter"></i></span>
		      <input type="text" class="form-control" name="twitter" ng-model="twitter" placeholder="https://www.twitter.com/usuario">
		    </div>
		  </div>
		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12">
		      <span class="input-group-addon" id="basic-addon1"><i class="fab fa-instagram"></i></span>
		      <input type="text" class="form-control" name="instagram" ng-model="instagram" placeholder="https://www.instagram.com/usuario">
		    </div>
		  </div>
		  <!--redes sociales-->
		  
		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-android"></i></span>
		      <input type="text" class="form-control" name="playstore" ng-model="playstore"  placeholder="Link PlayStore">
		    </div>
		  </div>
		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-windows"></i></span>
		      <input type="text" class="form-control" name="windows" ng-model="windows" placeholder="Link Windows Phone">
		    </div>
		  </div>

		  <div class="form-group col-sm-6 MB10" style="display: none;">
		    <div class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-apple"></i></span>
		      <input type="text" class="form-control" name="iphone" ng-model="iphone" placeholder="Link Iphone">
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10" style="visibility: hidden;">
		    <div class="input-group col-xs-12	">
		      <span class="input-group-addon" ><i class="fa fa-apple"></i></span>
		      <input type="text" class="form-control" >
		    </div>
		  </div>
		  
		  <br><br>
         <div class="col-xs-12 form-group MB10">
		  <label style="display: block;text-align: center;line-height: 150%;font-size: 1.25em;" >Configuraciónes del Reproductor. <br></label>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10">
		      <label>Color Fondo</label>
		      <br>
		      <div id="btncb" class="col-xs-12 SinPadding">
		    <select class="form-control" ng-model="btn" name="btn" id="btn">
				<option value="red" class="btn-red">Red</option>
		    		<option value="pink" class="btn-pink">Pink</option>
		    		<option value="purple" class="btn-purple">Purple</option>
		    		<option value="deeppurple" class="btn-deeppurple">Deeppurple</option>
		    		<option value="indigo" class="btn-indigo">Indigo</option>
		    		<option value="blue" class="btn-blue">Blue</option>
		    		<option value="lightblue" class="btn-lightblue">LightBlue</option>
		    		<option value="cyan" class="btn-cyan">Cyan</option>
		    		<option value="teal" class="btn-teal">Teal</option>
		    		<option value="green" class="btn-green">Green</option>
		    		<option value="lightgreen" class="btn-lightgreen">LightGreen</option>
		    		<option value="lime" class="btn-lime">Lime</option>
		    		<option value="yellow" class="btn-yellow">Yellow</option>
		    		<option value="amber" class="btn-amber">Amber</option>
		    		<option value="orange" class="btn-orange">Orange</option>
		    		<option value="deeporange" class="btn-deeporange">Deeporange</option>
		    		<option value="brown" class="btn-brown">Brown</option>
		    		<option value="grey" class="btn-grey">Grey</option>
		    		<option value="bluegrey" class="btn-bluegrey">BlueGrey</option>
		    		<option value="darkblue" class="btn-darkblue">DarkBlue</option>
		    		<option value="black" class="btn-black" ng-init="btn='black'">Black</option>
		    		<option value="white" class="btn-white">White</option>
		    		</select>
		    </div>
		  </div>
		  <div class="form-group col-sm-6 MB10">
		      <label>Color Botones</label>
		      <br>
		      <div id="abtncb" class="col-xs-12 SinPadding">
		    <select class="form-control" ng-model="abtn" name="abtn" id="abtn">
		    		<option value="red" class="abtn-red"><font color="#FFF">Red</font></option>
		    		<option value="pink" class="abtn-pink" ng-init="abtn='pink'">Pink</option>
		    		<option value="purple" class="abtn-purple">Purple</option>
		    		<option value="deeppurple" class="abtn-deeppurple">Deeppurple</option>
		    		<option value="indigo" class="abtn-indigo">Indigo</option>
		    		<option value="blue" class="abtn-blue">Blue</option>
		    		<option value="lightblue" class="abtn-lightblue">LightBlue</option>
		    		<option value="cyan" class="abtn-cyan">Cyan</option>
		    		<option value="teal" class="abtn-teal">Teal</option>
		    		<option value="green" class="abtn-green">Green</option>
		    		<option value="lightgreen" class="abtn-lightgreen">LightGreen</option>
		    		<option value="lime" class="abtn-lime">Lime</option>
		    		<option value="yellow" class="abtn-yellow">Yellow</option>
		    		<option value="amber" class="abtn-amber">Amber</option>
		    		<option value="orange" class="abtn-orange">Orange</option>
		    		<option value="deeporange" class="abtn-deeporange">Deeporange</option>
		    		<option value="brown" class="abtn-brown">Brown</option>
		    		<option value="grey" class="abtn-grey">Grey</option>
		    		<option value="bluegrey" class="abtn-bluegrey">BlueGrey</option>
		    		<option value="darkblue" class="abtn-darkblue">DarkBlue</option>
		    		<option value="black" class="abtn-black">Black</option>
		    		</select>
		    </div>
		  </div>
		  
		  <div class="col-xs-12 form-group MB10">
		  <label style="display: block;text-align: center;line-height: 150%;font-size: 1.25em;">Texto que reemplazara la metadata cuando no se encuentre. <br><br></label>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10">
		    <div id="Artista" class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-font"></i></span>
		      <input type="text" maxlength="20" class="form-control" name="artista" ng-model="artista" placeholder="Artista" ng-init="artista='En vivo'" onkeyup="countChars(this);" >
		      <span class="input-group-addon" id="charNum">7 / 20</span>
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10">
		    <div id="Cancion" class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-font"></i></span>
		      <input  type="text" maxlength="50" class="form-control" name="cancion"  ng-model="cancion" placeholder="Canción" ng-init="cancion='Buena Música las 24 horas!'" onkeyup="countChars2(this);" >
		      <span class="input-group-addon" id="charNum2">26 / 50</span>
		    </div>
		  </div>
		  
		 
		  
		  <!--Pantalla latidos-->
         <br><br>
         <div class="col-xs-12 form-group MB10">
		  <label style="display: block;text-align: center;line-height: 150%;font-size: 1.25em;" >Configuración de la pantalla del Reproductor. <br></label>
		  </div>
         
         <div class="form-group col-sm-6 MB10">
             <label>Texto Pantalla: </label>
		    <div id="Latidosid" class="input-group col-xs-12	">
		      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-font"></i></span>
		      <input type="text" maxlength="40" class="form-control" id="Latidos" name="latidos" ng-model="latidos" placeholder="Texto de Play" ng-init="latidos='Haga click para comenzar a reproducir'" onkeyup="countChars3(this);">
		      <span class="input-group-addon" id="charNum3">37 / 40</span>
		    </div>
		  </div>
         
         <div class="col-xs-6">
		    <label>Seleccionar Color: </label>
		    <div class="col-xs-12 SinPadding">
		    <div id="colorpicker" class="input-group colorpicker-component">
			    <input type="text" class="form-control" ng-model="color" name="color" class="campo-color" />
			    <span class="input-group-addon desplegable"><i style="background-color: rgb(255,255,255);"></i></span>
			    <span class="input-group-addon"><span class="fa fa-refresh" ng-click="CambiarColor()" ng-init="color='ffffff'" style="cursor: pointer;"></span></span>
			</div>

		    </div>
		  </div>
         
         <!--Pantalla latidos-->
         
         <div class="form-group col-sm-6 MB10" style="visibility: hidden;">
		    <div class="input-group col-xs-12	">
		      <span class="input-group-addon" ><i class="fa fa-apple"></i></span>
		      <input type="text" class="form-control" >
		    </div>
		  </div>

		  <div class="col-xs-6 form-group MB10">
		    <label>Seleccionar Tema: </label>
		    <div class="input-group col-xs-12">
		    	<span class="input-group-addon" id="basic-addon1"><i class="fa fa-paint-brush"></i></span>
		    	<select class="form-control" ng-model="TemaRep" ng-change="CambiarTema(TemaRep)" name="theme" id="theme" onChange="mostrar(this.value);" />
		    		<option value="uno">Default</option>
		    		<option value="dos">Tema Dos</option>
		    	</select>
		    </div>
		  </div>
		  
		  <div class="form-group col-sm-6 MB10">
		      <label>Layout </label><br>
		    <div id="vrtcb" class="col-xs-12 SinPadding">
		        <select class="form-control" ng-model="vrt" name="vrt" id="vrt">
		    		<option value="true">Vertical</option>
					<option value="false" ng-init="vrt='false'">Horizontal</option>
		        </select>
		    </div>
		  </div>


		  <div class="form-group col-sm-6 MB10">
           
           <div class="col-xs-4">
		      <label>Pantalla:</label>
		      <br>
		      <div id="Mamparacb" class="col-xs-12 SinPadding">
		    <select class="form-control" ng-init="Mampara='visible'" ng-model="Mampara" name="Mampara" id="Mampara">
				<option value='visible' class="btn-green">Si</option>
		    	<option value='hidden' class="btn-red">No</option>
		    		
		    		</select>
		    </div>
		  </div>
		  
		  
		  <div class="col-xs-4">
		    <label>AutoPlay: </label><br>
		    <div id="autoplayid" class="col-xs-12 SinPadding" >
		    <select class="form-control" ng-model="autoplay" name="autoplay" id="autoplay">
				<option value='true' ng-init="autoplay='true'" class="btn-green">Si</option>
		    	<option value='false' class="btn-red">No</option>
		    		
		    		</select>
		    </div>
		  </div>
		  
		  <div class="col-xs-4">
		   <label>Blur Effect</label><br>
		   <div id="blurid" class="col-xs-12 SinPadding" >
		    <select class="form-control" ng-model="blur" name="blur" id="blur">
				<option value='true' ng-init="blur='true'" class="btn-green">Si</option>
		    	<option value='false' class="btn-red">No</option>
		    		
		    		</select>
		    </div>
		  </div>
		  </div>

		  <?php echo $AlertaGenera; ?>

		   <div class="col-xs-12 form-group MB10">
		    <input class="form-control btn btn-primary text-left" type="submit" name="generar" value="Generar Código Reproductor HTML5" style=" width:79%;"> <br><br>
		    <a class="fileUpload btn btn-primary form-group pull-right" style=" width:20%; margin-bottom:0px;margin-top:-55px;padding:6px;" href="salir.php" >Salir</a>
		   </div>
		   

		  <div class="clearfix"></div>
		</form>
	
      </div>
      <!--/form-->
      
      <!--preview-->
      <div class="col-md-4 laterales MB10" style="padding:15px;">
		<h4>Vista Previa</h4>
		<div class="col-xs-12 vista-previa SinPadding" ng-class="" ng-show="TemaRep">
			<!--REPRODUCTOR-->
			<iframe frameborder="0" scrolling="no" style="width:100%;" onload="resizeIframe(this)" ng-src="{{'./reproductores/?&ip='+ipemisora+'&puerto='+puerto+'&montaje='+versionSC+'&titulo='+emisora+'&autoplay='+autoplay+'&blur='+blur+'&Mampara='+Mampara+'&vrt='+vrt+'&tema='+tema+'&abtn='+abtn+'&btn='+btn+'&facebook='+facebook+'&twitter='+twitter+'&instagram='+instagram+'&playstore='+playstore+'&messenger='+messenger+'&Whatsapp='+Whatsapp+'&enlace='+enlace+'&winamp='+winamp+'&color='+color+'&latidos='+latidos+'&artista='+artista+'&cancion='+cancion+'&logo='+logo+'&imgfacebook='+imgfacebook}}"></iframe>
			<!--FIN REPRODUCTOR-->
		</div><div class="clearfix"></div>
      </div>
      <!--/preview-->

      <!--upload-->
      <div class="col-md-4 laterales MB10" style="padding:15px;">
		<h4>Subir Logo <BR>Recomendado 200 X 200 hasta 50kb</h4>
		<div class="col-xs-12 vista-previa SinPadding">
			<!--REPRODUCTOR-->
			<iframe frameborder="0" scrolling="no" style="width:100%;" onload="resizeIframe(this)" src="upload.php"></iframe>
			<!--FIN REPRODUCTOR-->
		</div><div class="clearfix"></div>
      </div>
      <!--/upload-->
      
      <!--upload2-->
      <div class="col-md-4 laterales MB10" style="padding:15px;">
		<h4>Subir Imagen Facebook <BR>Recomendado 500 X 250 hasta 50kb</h4>
		<div class="col-xs-12 vista-previa SinPadding">
			<!--REPRODUCTOR-->
			<iframe frameborder="0" scrolling="no" style="width:100%;" onload="resizeIframe(this)" src="upload2.php"></iframe>
			<!--FIN REPRODUCTOR-->
		</div><div class="clearfix"></div>
      </div>
      <!--/upload2-->
      
      <!--codigo-->
      <?php 
      	if($InsertaSuccess){
      ?>
      
      <div class="col-xs-12 laterales" style="padding:15px; word-break: break-all;">
		<h4 class="pull-left">Código HTML</h4>
		<button class="btn btn-default btn-sm pull-right tooltip" id="copyClip" data-clipboard-target="#codhtml" onclick="copyClip2()" onmouseout="outFunc()"><i class="fa fa-copy"></i><span class="tooltiptext" id="myTooltip">Copiar al portapapeles</span>
  Copiar Código
  </button>
		<textarea class="form-control" height="150" style="resize: vertical; min-height:80px;" id="codhtml"><iframe frameborder="0" scrolling="no" width="100%" src="https://www.html5player.evolucionstreaming.com/reproductores/?idr=<?php echo base64_encode($id_rep); ?>"></iframe></textarea>
      </div><div class="clearfix"></div>
      <?php 
      	} 
      ?>
      <!--/codigo-->
     
    </div>
    <?php
		}else{
			//Login cavernicola
			?>
			<div style="width: 300px; height:250px;  margin:15px auto; background-color: rgba(255,255,255,0.7); border: 1px solid #333; border-radius: 5px; padding:30px;">
				<form action="?" method="POST">
					<label>Usuario</label>
					<input class="form-control" type="text" name="user">
					<label>Clave</label>
					<input class="form-control" type="password" name="pass">

					<input class="col-xs-12 btn btn-primary"  type="submit" value="Ingresar" style="margin-top: 20px;">
				</form>
			</div>
			<?php
		}
    ?>
    
    <!--Libs-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.4/clipboard.min.js"></script>

    <script src="js/angular.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-colorpicker.min.js"></script>
    <script src="js/bootstrap-colorpicker-module.min.js"></script>
    <script src="js/app.js"></script>
    <script type="text/javascript">
            $(document).ready(function(){
			function resizeIframe(obj) {
				obj.style.height = 0;
                obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
			}
			$(function() {
			    $('#colorpicker').colorpicker();

		        $('#colorpicker').on("change",function(){
		        	 $('#colorpicker input').attr('value',$('#colorpicker').colorpicker('getValue','ffffff'));
		        });

		        $('#Latidosid').Latidosid();

		        $('#Latidosid').on("change",function(){
		        	 $('#Latidosid input').attr('value',$('#Latidosid').Latidosid('getValue','Haga click para comenzar a reproducir'));
		        });
		        
		        $('#Artista').Artista();

		        $('#Artista').on("change",function(){
		        	 $('#Artista input').attr('value',$('#Artista').Artista('getValue','En vivo'));
		        });
		        
		        $('#Cancion').Cancion();

		        $('#Cancion').on("change",function(){
		        	 $('#Cancion input').attr('value',$('#Cancion').Cancion('getValue','Buena Música las 24 horas!'));
		        });
		        
		        $('#Cancion').Cancion();

		        $('#imgfacebook').on("change",function(){
		        	 $('#imgfacebook input').attr('value',$('#imgfacebook').imgfacebook('getValue','./reproductores/img/fb%20(1).png'));
		        });

                 $('#abtncb').abtncb();

		        $('#abtncb').on("change",function(){
		        	 $('#abtncb select').attr('value',$('#abtncb').abtncb('getValue','pink'));
		        });
		        
		        $('#vrtcb').vrtcb();
		        
		        $('#vrtcb').on("change",function(){
		            vrt = document.getElementById('vrt').value;
		        	 $('#vrtcb select').attr('value',$('#vrtcb').vrtcb('getValue','false'));
		        });
		        
		        $('#blurid').blurid();
		        
		        $('#blurid').on("change",function(){
		            blur = document.getElementById('blur').value;
		        	 $('#blurid select').attr('value',$('#blurid').blurid('getValue','false'));
		        });
		        
		        $('#btncb').btncb();

		        $('#btncb').on("change",function(){
		        	 $('#btncb select:text').attr('value',$('#btncb').btncb('getValue','black'));
		        });
		        
		        $('#autoplayid').autoplayid();
		        
		        $('#autoplayid').on("change",function(){
		            autoplay = document.getElementById('autoplay').value;
		        	 $('#autoplayid select').attr('value',$('#autoplayid').autoplayid('getValue','true'));
		        });
		        
		        $('#Mampara').Mampara();
		        
		        $('#Mampara').on("change",function(){
		            Mampara = document.getElementById('Mampara').value;
		        	 $('#Mampara select').attr('value',$('#Mampara').Mampara('getValue','hidden'));
		        });


                
			});
        });

function countChars(obj){
    var maxLength = 20;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    
    if(charRemain == 20){
        document.getElementById("charNum").innerHTML = '<span style="color: red;">20 / '+maxLength+'</span>';
    }else{
        document.getElementById("charNum").innerHTML = charRemain+' / 20';
    }
}
function countChars2(obj){
    var maxLength = 50;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    
    if(charRemain == 50){
        document.getElementById("charNum2").innerHTML = '<span style="color: red;">50 / '+maxLength+'</span>';
    }else{
        document.getElementById("charNum2").innerHTML = charRemain+' / 50';
    }
}
function countChars3(obj){
    var maxLength = 40;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    

    
    if(charRemain == 40){
        document.getElementById("charNum3").innerHTML = '<span style="color: red;">40 / '+maxLength+'</span>';
    }else{
        document.getElementById("charNum3").innerHTML = charRemain+' / 40';
    }
}
function countChars4(obj){
    var maxLength = 255;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    

    
    if(charRemain == 255){
        document.getElementById("charNum4").innerHTML = '<span style="color: red;">255 / '+maxLength+'</span>';
    }else{
        document.getElementById("charNum4").innerHTML = charRemain+' / 255';
    }
}
function countChars5(obj){
    var maxLength = 30;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    

    
    if(charRemain == 30){
        document.getElementById("charNum5").innerHTML = '<span style="color: red;">30 / '+maxLength+'</span>';
    }else{
        document.getElementById("charNum5").innerHTML = charRemain+' / 30';
    }
}
function countChars6(obj){
    var maxLength = 50;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    

    
    if(charRemain == 50){
        document.getElementById("charNum6").innerHTML = '<span style="color: red;">50 / '+maxLength+'</span>';
    }else{
        
        document.getElementById("charNum6").innerHTML = charRemain+' / 50';
    }
}
function countChars7(obj){
    var maxLength = 255;
    var strLength = obj.value.length;
    var charRemain = ( + strLength);
    

    
    if(charRemain == 255){
        document.getElementById("charNum7").innerHTML = '<span style="color: red;">255 / '+maxLength+'</span>';
    }else{
        
        document.getElementById("charNum7").innerHTML = charRemain+' / 255';
    }
}
</script>

<script type="text/javascript">
function mostrar(id) {
    if (id == "tres") {
        $("#tres").show();
        $("#dos").hide();
    }

    if (id == "dos") {
        $("#tres").hide();
        $("#dos").show();
    }
}
function mayus(e) {
    e.value = e.value.toUpperCase();
}
</script>

<!--<script type="text/javascript">
        var button = document.getElementById("copyClip"),
            input = document.getElementById("codhtml");

        button.addEventListener("click", function(event) {
            event.preventDefault();
            input.select();
            document.execCommand("copy");
        });
    </script>--->
<script>
function copyClip2() {
  var copyText = document.getElementById("codhtml");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  document.execCommand("copy");
  
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Código copiado correctamente";
}

function outFunc() {
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Copiar código al portapapeles";
}
</script>

  </body>
</html>